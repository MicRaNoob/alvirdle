custom = ["BUS","GYM","INK","MAP","ART","TRY","JOB"];

beginner = ["BUS","GYM","INK","MAP","ART","TRY","JOB"];

intermediate = beginner.concat(["CTE","GEO","SAT","AHS","ACT","VET","ASK","LOW"]);

advanced = intermediate.concat(["PEP","HOW","WHY","SIT","NET","RUN","JOG"]);

fullList = advanced.concat(["COW","SAU","MRS","FOX","TIP","USE","PEN","ASL"]);