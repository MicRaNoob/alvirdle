custom = ["COLE","MATH","BOOK","EXAM","TEST","QUIZ","GLUE","TAPE","FILE","WORK","HALL","FLAG","CALC","KING"];

beginner = ["COLE","MATH","BOOK","EXAM","TEST","QUIZ","GLUE","TAPE","FILE","WORK","HALL","FLAG","CALC","KING"];

intermediate = beginner.concat(["CLUB","BAND","KNOW","BELL","HELP","WEEK","FOOD","CORE","NEED","SAFE","GAME","GOLF","BALL","WALK","ROSE"]);

advanced = intermediate.concat(["DOOR","TIME","EDIT","TASK","FARM","BARN","VOTE","MISS","DONE","CODE","MAIL","HARD","EASY","RULE"]);

fullList = advanced.concat(["WORD","POEM","GOAL","HINT","MARK","GORA","FAIR","GOLD","NEWS","READ","NINE","RUSH","PROM","HOCO","SING"]);